$(document).ready(function () {

    $('#send_data').click(function () {
	
			
			alert("Please type the activation code and try again");
			
	});
	
});

