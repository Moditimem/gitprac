<?php
	
	$dbhost = '192.168.0.244';
	$dbuser = 'Web_User';
	$dbpass = 'm]D/F[:228c9 >K';
	$dbname = 'Telesave';

?>